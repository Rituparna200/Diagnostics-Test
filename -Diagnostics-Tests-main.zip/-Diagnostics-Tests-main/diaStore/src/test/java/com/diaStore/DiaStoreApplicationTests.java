package com.diaStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiaStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
